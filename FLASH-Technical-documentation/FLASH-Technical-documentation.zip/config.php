<?php 
/**
 * [PHPFOX_HEADER]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond_Benc
 * @package 		Phpfox
 * @version 		$Id: add.html.php 2874 2011-08-23 08:40:57Z Raymond_Benc $
 */

/**
 * Full path to where the API site is located.
 */
define('APP_URL', 'https://xn--b1agipv.xn--80asehdb/tools/apps/ПАПКА_НАЗВАНИЕ_ПРИЛОЖЕНИЯ/');

/**
 * Public key you get when creating an APP.
 */
define('APP_PUBLIC_KEY', 'КЛЮЧ_APP_ID');

/**
 * Private key you get when creating an APP.
 */
define('APP_PRIVATE_KEY', 'КЛЮЧ_APP_ID');

?>